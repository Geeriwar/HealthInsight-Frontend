import { useEffect, useState } from "react";

function Dashboard() {
  const [profile, setProfile] = useState(null);
  const [datasetName, setDatasetName] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function fetchDatasetProfile() {
      try {
        const response = await fetch(
          "http://127.0.0.1:8000/api/datasets/diabetes/profile"
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.detail || "Failed to load dataset profile.");
        }

        setDatasetName(data.dataset);
        setProfile(data.profile);
      } catch (error) {
        setErrorMessage(error.message);
      } finally {
        setIsLoading(false);
      }
    }

    fetchDatasetProfile();
  }, []);

  if (isLoading) {
    return (
      <main className="page-container">
        <h1>Healthcare Dashboard</h1>
        <p>Loading dataset analytics...</p>
      </main>
    );
  }

  if (errorMessage) {
    return (
      <main className="page-container">
        <h1>Healthcare Dashboard</h1>
        <div className="error-message">{errorMessage}</div>
      </main>
    );
  }

  return (
    <main className="page-container">
      <div className="page-heading">
        <p className="page-label">Diabetes Analytics</p>
        <h1>{datasetName}</h1>
        <p>
          Overview of dataset size, quality, structure and diabetes-class
          distribution.
        </p>
      </div>

      <section className="summary-grid">
        <div className="summary-card">
          <p>Total Records</p>
          <h2>{profile.rows.toLocaleString()}</h2>
        </div>

        <div className="summary-card">
          <p>Total Columns</p>
          <h2>{profile.columns}</h2>
        </div>

        <div className="summary-card">
          <p>Missing Values</p>
          <h2>{profile.total_missing_values}</h2>
        </div>

        <div className="summary-card">
          <p>Duplicate Rows</p>
          <h2>{profile.duplicate_rows.toLocaleString()}</h2>
        </div>

        <div className="summary-card">
          <p>Numerical Columns</p>
          <h2>{profile.numeric_column_count}</h2>
        </div>

        <div className="summary-card">
          <p>Categorical Columns</p>
          <h2>{profile.categorical_column_count}</h2>
        </div>

        <div className="summary-card">
          <p>Memory Usage</p>
          <h2>{profile.memory_usage_megabytes} MB</h2>
        </div>

        <div className="summary-card">
          <p>Target Column</p>
          <h2>{profile.target_column}</h2>
        </div>
      </section>

      <section className="data-section">
        <h2>Diabetes Distribution</h2>

        <div className="target-grid">
          {profile.target_distribution.map((item) => (
            <div className="target-card" key={item.value}>
              <p>
                {item.value === "1"
                  ? "Diabetes Patients"
                  : "Non-Diabetes Patients"}
              </p>

              <h3>{item.count.toLocaleString()}</h3>
              <span>{item.percentage}% of records</span>
            </div>
          ))}
        </div>
      </section>

      <section className="data-section">
        <h2>Column Information</h2>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Column</th>
                <th>Data Type</th>
                <th>Missing</th>
                <th>Unique Values</th>
                <th>Example</th>
              </tr>
            </thead>

            <tbody>
              {profile.column_information.map((item) => (
                <tr key={item.column}>
                  <td>{item.column}</td>
                  <td>{item.data_type}</td>
                  <td>{item.missing_values}</td>
                  <td>{item.unique_values}</td>
                  <td>{String(item.example_value)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="data-section">
        <h2>Dataset Preview</h2>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                {profile.column_names.map((column) => (
                  <th key={column}>{column}</th>
                ))}
              </tr>
            </thead>

            <tbody>
              {profile.preview.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {profile.column_names.map((column) => (
                    <td key={`${rowIndex}-${column}`}>
                      {String(row[column] ?? "")}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}

export default Dashboard;