import PredictionForm from "../components/PredictionForm";

function Prediction() {
  return (
    <main className="page-container">
      <h1>Disease Risk Prediction</h1>

      <PredictionForm />
    </main>
  );
}

export default Prediction;