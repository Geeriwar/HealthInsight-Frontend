import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Home() {
  const [backendStatus, setBackendStatus] = useState("Checking...");
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    async function checkBackend() {
      try {
        const response = await fetch(
          "http://127.0.0.1:8000/api/health"
        );

        if (!response.ok) {
          throw new Error("Backend response failed");
        }

        const data = await response.json();

        setBackendStatus(data.status);
        setIsOnline(true);
      } catch (error) {
        console.error(error);
        setBackendStatus("Offline");
        setIsOnline(false);
      }
    }

    checkBackend();
  }, []);

  return (
    <main className="hero">
      <section className="hero-content">
        <p className="tag">Healthcare Data Analytics Platform</p>

        <h1>
          Transform Healthcare Data Into
          <span> Meaningful Insights</span>
        </h1>

        <p className="hero-description">
          Analyze medical datasets, discover important health patterns,
          compare machine-learning models, and estimate disease risk through
          one interactive platform.
        </p>

        <div className="backend-status">
          <span
            className={`status-dot ${
              isOnline ? "online-dot" : "offline-dot"
            }`}
          ></span>

          Backend status: <strong>{backendStatus}</strong>
        </div>

        <div className="hero-buttons">
          <Link to="/dashboard" className="primary-button">
            Explore Dashboard
          </Link>

          <Link to="/about" className="secondary-button">
            Learn More
          </Link>
        </div>
      </section>

      <section className="hero-card">
        <div className="dashboard-preview">
          <div className="preview-header">
            <div>
              <p>Patient Analytics</p>
              <h2>Health Overview</h2>
            </div>

            <span className="status">
              {isOnline ? "Connected" : "Disconnected"}
            </span>
          </div>

          <div className="metric-grid">
            <div className="metric-card">
              <p>Total Records</p>
              <h3>768</h3>
            </div>

            <div className="metric-card">
              <p>Positive Cases</p>
              <h3>268</h3>
            </div>

            <div className="metric-card">
              <p>Average Glucose</p>
              <h3>120.9</h3>
            </div>

            <div className="metric-card">
              <p>Backend</p>
              <h3>{backendStatus}</h3>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Home;