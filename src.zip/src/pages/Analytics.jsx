import { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        const response = await fetch(
          "http://127.0.0.1:8000/api/datasets/diabetes/eda"
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data.detail || "Unable to load analytics data."
          );
        }

        setAnalytics(data);
      } catch (error) {
        setErrorMessage(error.message);
      } finally {
        setIsLoading(false);
      }
    }

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return (
      <main className="page-container">
        <h1>Data Analytics</h1>
        <p>Loading healthcare analytics...</p>
      </main>
    );
  }

  if (errorMessage) {
    return (
      <main className="page-container">
        <h1>Data Analytics</h1>
        <div className="error-message">
          {errorMessage}
        </div>
      </main>
    );
  }

  const { overview, gender_distribution, target_distribution } =
    analytics;

  return (
    <main className="page-container">
      <div className="page-heading">
        <p className="page-label">
          Exploratory Data Analysis
        </p>

        <h1>{analytics.dataset}</h1>

        <p>
          Interactive analysis of the cleaned diabetes
          dataset.
        </p>
      </div>

      <section className="summary-grid">
        <div className="summary-card">
          <p>Cleaned Records</p>
          <h2>{overview.rows.toLocaleString()}</h2>
        </div>

        <div className="summary-card">
          <p>Total Columns</p>
          <h2>{overview.columns}</h2>
        </div>

        <div className="summary-card">
          <p>Numerical Columns</p>
          <h2>{overview.numerical_columns}</h2>
        </div>

        <div className="summary-card">
          <p>Categorical Columns</p>
          <h2>{overview.categorical_columns}</h2>
        </div>
      </section>

      <section className="analytics-grid">
        <article className="chart-section">
          <div className="chart-section-header">
            <h2>Gender Distribution</h2>
            <p>
              Distribution of patient records by gender.
            </p>
          </div>

          <div className="chart-container">
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={gender_distribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="gender" />
                <YAxis />
                <Tooltip />
                <Bar
                  dataKey="count"
                  name="Patients"
                  fill="#0f8b8d"
                  radius={[8, 8, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="chart-section">
          <div className="chart-section-header">
            <h2>Diabetes Distribution</h2>
            <p>
              Comparison of diabetic and non-diabetic
              records.
            </p>
          </div>

          <div className="chart-container">
            <ResponsiveContainer width="100%" height={320}>
              <PieChart>
                <Pie
                  data={target_distribution}
                  dataKey="count"
                  nameKey="label"
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={110}
                  paddingAngle={4}
                >
                  {target_distribution.map((entry, index) => (
                    <Cell
                      key={entry.value}
                      fill={
                        index === 0
                          ? "#0f8b8d"
                          : "#e07a5f"
                      }
                    />
                  ))}
                </Pie>

                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </article>
      </section>

      <section className="data-section">
        <h2>Key Observations</h2>

        <div className="observation-list">
          <div className="observation-card">
            <h3>Gender Composition</h3>
            <p>
              Female records represent{" "}
              {gender_distribution[0].percentage}% of the
              cleaned dataset.
            </p>
          </div>

          <div className="observation-card">
            <h3>Class Imbalance</h3>
            <p>
              Only{" "}
              {
                target_distribution.find(
                  (item) => item.value === 1
                )?.percentage
              }
              % of records are diabetic. This imbalance must
              be handled during model training.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Analytics;