import { useState } from "react";
import { predictDiabetes } from "../services/api";

function PredictionForm() {
  const [formData, setFormData] = useState({
    gender: "",
    age: "",
    hypertension: 0,
    heart_disease: 0,
    smoking_history: "",
    bmi: "",
    HbA1c_level: "",
    blood_glucose_level: "",
  });

  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  async function handleSubmit(event) {
    event.preventDefault();

    setLoading(true);

    try {
      const response = await predictDiabetes({
        gender: formData.gender,
        age: Number(formData.age),
        hypertension: Number(formData.hypertension),
        heart_disease: Number(formData.heart_disease),
        smoking_history: formData.smoking_history,
        bmi: Number(formData.bmi),
        HbA1c_level: Number(formData.HbA1c_level),
        blood_glucose_level: Number(formData.blood_glucose_level),
      });

      setResult(response.result);
    } catch (error) {
      console.error(error);
      alert("Prediction Failed!");
    }

    setLoading(false);
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>

        <h2>Disease Risk Prediction</h2>

        <div>
          <label>Gender</label>
          <br />
          <select
            name="gender"
            value={formData.gender}
            onChange={handleChange}
            required
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>

        <br />

        <div>
          <label>Age</label>
          <br />
          <input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            required
          />
        </div>

        <br />

        <div>
          <label>Hypertension</label>
          <br />
          <select
            name="hypertension"
            value={formData.hypertension}
            onChange={handleChange}
          >
            <option value={0}>No</option>
            <option value={1}>Yes</option>
          </select>
        </div>

        <br />

        <div>
          <label>Heart Disease</label>
          <br />
          <select
            name="heart_disease"
            value={formData.heart_disease}
            onChange={handleChange}
          >
            <option value={0}>No</option>
            <option value={1}>Yes</option>
          </select>
        </div>

        <br />

        <div>
          <label>Smoking History</label>
          <br />
          <select
            name="smoking_history"
            value={formData.smoking_history}
            onChange={handleChange}
            required
          >
            <option value="">Select</option>
            <option value="never">Never</option>
            <option value="former">Former</option>
            <option value="current">Current</option>
            <option value="No Info">No Info</option>
            <option value="ever">Ever</option>
            <option value="not current">Not Current</option>
          </select>
        </div>

        <br />

        <div>
          <label>BMI</label>
          <br />
          <input
            type="number"
            step="0.01"
            name="bmi"
            value={formData.bmi}
            onChange={handleChange}
            required
          />
        </div>

        <br />

        <div>
          <label>HbA1c Level</label>
          <br />
          <input
            type="number"
            step="0.1"
            name="HbA1c_level"
            value={formData.HbA1c_level}
            onChange={handleChange}
            required
          />
        </div>

        <br />

        <div>
          <label>Blood Glucose Level</label>
          <br />
          <input
            type="number"
            name="blood_glucose_level"
            value={formData.blood_glucose_level}
            onChange={handleChange}
            required
          />
        </div>

        <br />

        <button type="submit" disabled={loading}>
          {loading ? "Predicting..." : "Predict Diabetes"}
        </button>

      </form>

      {result && (
        <div
          style={{
            marginTop: "30px",
            padding: "20px",
            border: "1px solid #ddd",
            borderRadius: "10px",
          }}
        >
          <h2>Prediction Result</h2>

          <h3>{result.label}</h3>

          <p>
            <strong>Prediction:</strong>{" "}
            {result.prediction}
          </p>

          <p>
            <strong>Diabetic Probability:</strong>{" "}
            {(result.probability.diabetic * 100).toFixed(2)}%
          </p>

          <p>
            <strong>Non-Diabetic Probability:</strong>{" "}
            {(result.probability.non_diabetic * 100).toFixed(2)}%
          </p>
        </div>
      )}
    </div>
  );
}

export default PredictionForm;